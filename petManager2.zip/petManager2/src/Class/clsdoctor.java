/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Class;

/**
 *
 * @author SENA
 */
public class clsdoctor {
    
    public String name;
    public String licencia;

    public clsdoctor(String name, String licencia) {
        this.name = name;
        this.licencia = licencia;
    }
    
    public clsdoctor() {

    }

    public void setName(String name) {
        this.name = name;
    }

    public void setLicencia(String licencia) {
        this.licencia = licencia;
    }

    public String getName() {
        return name;
    }

    public String getLicencia() {
        return licencia;
    }
    
    
    
}
